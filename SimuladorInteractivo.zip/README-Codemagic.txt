# SimuladorInteractivo — Cómo construir la APK con Codemagic

Archivos incluidos:
- `codemagic.yaml` (en minúsculas, en la raíz): configuración lista para Codemagic.
- Carpeta `SimuladorInteractivo/` con el proyecto Android (AGP 8.5.0 / Kotlin 2.0.0).

Pasos rápidos:
1) Sube este repositorio a GitHub/GitLab/Bitbucket tal cual (con `codemagic.yaml` en la raíz).
2) Entra a Codemagic → Add application → conecta el repo → selecciona la rama.
3) Codemagic detectará `codemagic.yaml`. Ejecuta el workflow **Android APK (debug) — SimuladorInteractivo**.
4) Al finalizar, descarga la APK desde la pestaña **Artifacts**.

Notas importantes:
- Tu proyecto NO trae `gradlew` (Gradle Wrapper). El YAML intenta usarlo si existe, y si no, usa `gradle` (preinstalado en Codemagic). 
- Si por versión de AGP necesitas Gradle 8.7 o superior y el preinstalado no coincide, añade un paso previo para instalarlo vía SDKMAN o descargando el binario.
- Este flujo genera **APK debug** (instalable en el móvil). Para **release**, habrá que configurar firma (keystore) y usar `assembleRelease`.
