package com.example.simuladorinteractivo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    SimulatorScreen()
                }
            }
        }
    }
}

data class CompanyInput(
    val name: String,
    var priceKwh: String = "",
    var fixedMonthly: String = ""
)

@Composable
fun SimulatorScreen() {
    var consumo by remember { mutableStateOf("300") } // kWh/mes por defecto
    var potencia by remember { mutableStateOf("4.6") } // kW
    var precioPotencia by remember { mutableStateOf("3.5") } // €/kW/mes

    var companies by remember {
        mutableStateOf(
            listOf(
                CompanyInput("Compañía 1"),
                CompanyInput("Compañía 2"),
                CompanyInput("Compañía 3")
            )
        )
    }

    val results = companies.map { c ->
        val pKwh = c.priceKwh.toDoubleOrNull() ?: 0.0
        val fixed = c.fixedMonthly.toDoubleOrNull() ?: 0.0
        val kwh = consumo.toDoubleOrNull() ?: 0.0
        val pot = potencia.toDoubleOrNull() ?: 0.0
        val pricePot = precioPotencia.toDoubleOrNull() ?: 0.0
        val energyCost = kwh * pKwh
        val potenciaCost = pot * pricePot
        val monthly = energyCost + potenciaCost + fixed
        val annual = monthly * 12
        CompanyResult(c.name, monthly, annual)
    }

    val best = results.minByOrNull { it.monthlyCost }?.name

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Simulador de Energía", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))

        // Inputs generales
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(value = consumo, onValueChange = { consumo = it }, label = { Text("Consumo mensual (kWh)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = potencia, onValueChange = { potencia = it }, label = { Text("Potencia contratada (kW)") }, modifier = Modifier.weight(1f))
            OutlinedTextField(value = precioPotencia, onValueChange = { precioPotencia = it }, label = { Text("Precio potencia (€/kW/mes)") }, modifier = Modifier.weight(1f))
        }

        Spacer(Modifier.height(12.dp))
        Text("Tarifas por compañía", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        companies.forEachIndexed { idx, c ->
            Spacer(Modifier.height(8.dp))
            Card {
                Column(Modifier.padding(12.dp)) {
                    OutlinedTextField(value = c.name, onValueChange = { new -> companies = companies.toMutableList().also { it[idx] = it[idx].copy(name = new) } }, label = { Text("Nombre") })
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(value = c.priceKwh, onValueChange = { companies = companies.toMutableList().also { it[idx] = it[idx].copy(priceKwh = it[idx].priceKwh); it[idx].priceKwh = it[idx].priceKwh.replace(',', '.'); it[idx] = it[idx].copy(priceKwh = it[idx].priceKwh); } }, label = { Text("Precio energía (€/kWh)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = c.fixedMonthly, onValueChange = { companies = companies.toMutableList().also { it[idx] = it[idx].copy(fixedMonthly = it[idx].fixedMonthly); it[idx].fixedMonthly = it[idx].fixedMonthly.replace(',', '.'); it[idx] = it[idx].copy(fixedMonthly = it[idx].fixedMonthly); } }, label = { Text("Fijo mensual (€)") }, modifier = Modifier.weight(1f))
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        Text("Resultados", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(6.dp))

        results.forEach { r ->
            val tag = if (r.name == best) " (Mejor)" else ""
            Text("${'$'}{{"%.2f".format(r.monthlyCost)}} / mes — ${r.name}{tag}")
        }

        Spacer(Modifier.height(12.dp))
        Divider()
        Spacer(Modifier.height(12.dp))

        ResultsTable(results, bestName = best)
    }
}

data class CompanyResult(val name: String, val monthlyCost: Double, val annualCost: Double)

@Composable
fun ResultsTable(results: List<CompanyResult>, bestName: String?) {
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Compañía", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
            Text("€/mes", modifier = Modifier.weight(1f), textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
            Text("€/año", modifier = Modifier.weight(1f), textAlign = TextAlign.End, fontWeight = FontWeight.Bold)
        }
        Divider()
        results.forEach { r ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(r.name + (if (r.name == bestName) " ★" else ""), modifier = Modifier.weight(1f))
                Text(String.format("%.2f", r.monthlyCost), modifier = Modifier.weight(1f), textAlign = TextAlign.End)
                Text(String.format("%.2f", r.annualCost), modifier = Modifier.weight(1f), textAlign = TextAlign.End)
            }
        }
    }
}